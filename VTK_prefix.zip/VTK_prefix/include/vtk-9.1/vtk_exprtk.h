/*=========================================================================

  Program:   Visualization Toolkit
  Module:    vtk_exprtk.h

  Copyright (c) Ken Martin, Will Schroeder, Bill Lorensen
  All rights reserved.
  See Copyright.txt or http://www.kitware.com/Copyright.htm for details.

     This software is distributed WITHOUT ANY WARRANTY; without even
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
     PURPOSE.  See the above copyright notice for more information.

=========================================================================*/
#ifndef vtk_exprtk_h
#define vtk_exprtk_h

/* Use the exprtk library configured for VTK.  */
#define VTK_MODULE_USE_EXTERNAL_VTK_exprtk 0

#if VTK_MODULE_USE_EXTERNAL_VTK_exprtk
# include <exprtk.hpp>
#else
# include <vtkexprtk/exprtk.hpp>
#endif

#endif
